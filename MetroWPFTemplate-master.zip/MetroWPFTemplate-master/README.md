# Metro WPF Template #
## Quickly and Easily create Metro WPF Applications with this template. ##

__This is still work in progress as, of right now, it's just a stripped down version of another project I was working on. Expect it to get cleaner and better over time. Hopefully.__

![A preview of what you're downloading...](http://i.imgur.com/2U9Na.png)

This shit is licensed under the [DBAD](http://www.dbad-license.org/ "DBAD") license, so don't be a dick and steal it, etc.

Have an issue? Chances are you are not alone. Report it on the [Issue Tracker](https://github.com/Xerax/MetroWPFTemplate/issues/new "Issue Tracker")

___The Segoe WP fonts, Metro Design Language (now Modern... lol), etc used are registered Trademarks of Microsoft Corp___
