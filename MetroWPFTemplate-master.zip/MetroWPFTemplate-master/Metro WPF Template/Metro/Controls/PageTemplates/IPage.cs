﻿namespace MetroWPFTemplate.Metro.Controls.PageTemplates
{
	public interface IPage
	{
		bool Close();
	}
}
